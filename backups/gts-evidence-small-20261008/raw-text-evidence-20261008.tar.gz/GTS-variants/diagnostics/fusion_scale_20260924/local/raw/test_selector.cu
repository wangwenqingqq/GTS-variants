// Small device regression check, including stale capacity and nonidentity maps.
#include <cuda_runtime.h>
#include <algorithm>
#include <cassert>
#include <cstdio>
#include <random>
#include <vector>
#include "fused_result.cuh"
void ck(cudaError_t e){if(e!=cudaSuccess){fprintf(stderr,"CUDA error: %s\n",cudaGetErrorString(e));exit(2);}}
template<class T> void alloc(T*& p,int n){ck(cudaMalloc(&p,n*sizeof(T)));}
int main(){
    std::mt19937 rng(20260923);int cases=0;
    for(int cap:{111,1111,11111,111111}){int slots=cap*20;
        int *nc,*flags,*ri,*prefix,*count,*oi;float *rd,*od;
        alloc(nc,1);alloc(flags,slots);alloc(ri,slots);alloc(rd,slots);alloc(prefix,slots);alloc(count,1);alloc(oi,(slots+2));alloc(od,(slots+2));
        std::vector<int> hflags(slots),hri(slots),hp(slots),actual((slots+2));
        std::vector<float> hrd(slots),dist((slots+2));
        for(int i=0;i<slots;++i){hri[i]=(i*137+73)%slots;hp[i]=i/7;hrd[i]=float((i*31)%101)/4;}
        ck(cudaMemcpy(ri,hri.data(),(slots*4),cudaMemcpyHostToDevice));ck(cudaMemcpy(rd,hrd.data(),(slots*4),cudaMemcpyHostToDevice));
        ck(cudaMemcpy(prefix,hp.data(),(slots*4),cudaMemcpyHostToDevice));
        for(int nodes:{cap,1,0,cap-1,26,25,52,51,2,cap,0})for(int pattern=0;pattern<4;++pattern){
            // Inactive flags are deliberately hits: the kernel must not inspect them.
            std::fill(hflags.begin(),hflags.end(),1);
            std::vector<int> want;std::vector<float> wd;
            for(int i=0;i<nodes*20;++i){
                hflags[i]=pattern==0?1:pattern==1?0:pattern==2?int(rng()%7==0):int(i%512==0||i%512==511);
                if(hflags[i]){want.push_back(hri[i]-hp[hri[i]]);wd.push_back(hrd[i]);}
            }
            ck(cudaMemcpy(nc,&nodes,4,cudaMemcpyHostToDevice));ck(cudaMemcpy(flags,hflags.data(),(slots*4),cudaMemcpyHostToDevice));
            ck(cudaMemset(oi,0xff,(slots+2)*4));ck(cudaMemset(od,0,(slots+2)*4));
            fusedResultSelect<<<1,512>>>(nc,flags,ri,rd,prefix,count,oi,od,cap);ck(cudaGetLastError());ck(cudaDeviceSynchronize());
            int n;ck(cudaMemcpy(&n,count,4,cudaMemcpyDeviceToHost));assert(n==int(want.size()));
            ck(cudaMemcpy(actual.data(),oi,(slots+2)*4,cudaMemcpyDeviceToHost));ck(cudaMemcpy(dist.data(),od,(slots+2)*4,cudaMemcpyDeviceToHost));
            assert(std::equal(want.begin(),want.end(),actual.begin()));assert(std::equal(wd.begin(),wd.end(),dist.begin()));
            assert(std::all_of(actual.begin()+n,actual.end(),[](int x){return x==-1;}));++cases;
        }
        for(void* p:{(void*)nc,(void*)flags,(void*)ri,(void*)rd,(void*)prefix,(void*)count,(void*)oi,(void*)od})ck(cudaFree(p));
    }
    printf("PASS selector %d cases; ordered payload, nonidentity prefix, poisoned tail and pointer churn\n",cases);
}

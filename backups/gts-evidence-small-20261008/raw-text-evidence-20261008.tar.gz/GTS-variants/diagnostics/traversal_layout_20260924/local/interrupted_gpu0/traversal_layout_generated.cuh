#pragma once
__device__ __forceinline__ void inlineInit(int *query_node_list, int qnum, int *max_node_num)
{
	int id = blockDim.x * blockIdx.x + threadIdx.x;
	int total_num = gridDim.x * blockDim.x;
	float num = qnum * max_node_num[0];

	for (int idx = id; idx < num; idx += total_num)
	{
		if (idx % max_node_num[0] == 0)
		{
			query_node_list[idx] = 1;
		}
		else
		{
			query_node_list[idx] = 0;
		}
	}
}
__device__ __forceinline__ void inlineClear(int *query_node_list, int start_idx, int node_num, int *max_node_num, int *empty_list)
{
	int bid = blockIdx.x;
	int tid = threadIdx.x;
	int query_id = bid;

	for (int i = tid; i < node_num; i += blockDim.x)
	{
		int nid = start_idx + i;
		int nid_parent = (nid - 1) / TREE_ORDER;

		if ((query_node_list[query_id * max_node_num[0] + nid_parent] == 1) && (empty_list[nid] == 0) && (nid - 1) % TREE_ORDER == 0)
		{
			query_node_list[query_id * max_node_num[0] + nid_parent] = 0;
		}
	}
}
template<bool Count> __device__ __forceinline__ void inlineWalk(int *query_node_list, int start_idx, TN *node_list, float r, float *data_d,
							int *qid_list, int node_num, int *max_node_num, int *data_info, int *empty_list, char *data_s, int *size_s, int *work)
{
	int bid = blockIdx.x;
	int tid = threadIdx.x;
	int query_id = bid;

	for (int i = tid; i < node_num; i += blockDim.x)
	{
		int nid = start_idx + i;
		int nid_parent = (nid - 1) / TREE_ORDER;

		if ((query_node_list[query_id * max_node_num[0] + nid_parent] == 1) && (empty_list[nid] == 0))
		{
			TN node = node_list[nid];

			if constexpr (Count) atomicAdd(work, 1);
            float dis_q = 0;
			if (data_info[2] == 2)
			{ // L2 distance
				for (int j = 0; j < data_info[0]; j++)
				{
					dis_q += pow(data_d[node.pid * data_info[0] + j] - data_d[qid_list[query_id] * data_info[0] + j], 2);
				}
				dis_q = pow(dis_q, 0.5);
			}
			else if (data_info[2] == 1)
			{ // L1 distance
				for (int j = 0; j < data_info[0]; j++)
				{
					dis_q += abs(data_d[node.pid * data_info[0] + j] - data_d[qid_list[query_id] * data_info[0] + j]);
				}
			}
			else if (data_info[2] == 0)
			{ // Max value
				float temp = 0;
				for (int j = 0; j < data_info[0]; j++)
				{
					temp = abs(data_d[node.pid * data_info[0] + j] - data_d[qid_list[query_id] * data_info[0] + j]);
					if (temp > dis_q)
						dis_q = temp;
				}
			}
			else if (data_info[2] == 5)
			{
				float sa1 = 0, sa2 = 0, sa3 = 0;
				for (int j = 0; j < data_info[0]; j++)
				{
					sa1 += data_d[node.pid * data_info[0] + j] * data_d[node.pid * data_info[0] + j];
					sa2 += data_d[qid_list[query_id] * data_info[0] + j] * data_d[qid_list[query_id] * data_info[0] + j];
					sa3 += data_d[node.pid * data_info[0] + j] * data_d[qid_list[query_id] * data_info[0] + j];
				}
				sa1 = pow(sa1, 0.5);
				sa2 = pow(sa2, 0.5);
				if (sa1 * sa2 == 0)
				{
					printf("Error!!!\n");
				}
				dis_q = sa3 / (sa1 * sa2);
				if (dis_q > 1)
				{
					dis_q = 0.99999999999999999;
				}
				dis_q = abs(acos(dis_q) * 180 / 3.1415926);
			}
			else if (data_info[2] == 6)
			{
				int n = size_s[node.pid];
				int m = size_s[qid_list[query_id]];
				int table[M][M];
				if (n == 0)
					dis_q = m;
				if (m == 0)
					dis_q = n;
				if (n != 0 && m != 0)
				{
					for (int j = 0; j <= n; j++)
						table[j][0] = j;
					for (int k = 0; k <= m; k++)
						table[0][k] = k;
					for (int j = 1; j <= n; j++)
					{
						for (int k = 1; k <= m; k++)
						{
							int cost = (data_s[node.pid * M + j - 1] == data_s[qid_list[query_id] * M + k - 1]) ? 0 : 1;
							table[j][k] = 1 + min(table[j - 1][k], table[j][k - 1]);
							table[j][k] = min(table[j - 1][k - 1] + cost, table[j][k]);
						}
					}
					dis_q = table[n][m];
				}
			}

			float dis_lb = node.min_dis - dis_q;
			dis_lb = max(dis_lb, 0.0);
			if (nid % TREE_ORDER != 0)
			{
				float dis_lb2 = dis_q - node_list[nid + 1].min_dis;
				dis_lb = max(dis_lb, dis_lb2);
			}

			if (dis_lb <= r)
				query_node_list[query_id * max_node_num[0] + nid] = 1;
		}
	}
}

// Counter variants are instantiated only by the diagnostic executable.
template<bool Count>
__global__ void auditLevel(int *query_node_list, int start_idx, TN *node_list, float r, float *data_d,
							int *qid_list, int node_num, int *max_node_num, int *data_info, int *empty_list, char *data_s, int *size_s, int *work) {
    inlineWalk<Count>(query_node_list, start_idx, node_list, r, data_d, qid_list, node_num, max_node_num, data_info, empty_list, data_s, size_s, work);
}

template<bool Count>
__global__ void fusedTraversal(int *query_node_list, int start_idx, TN *node_list, float r, float *data_d,
							int *qid_list, int node_num, int *max_node_num, int *data_info, int *empty_list, char *data_s, int *size_s, int height, int *work) {
    inlineInit(query_node_list, 1, max_node_num);
    __syncthreads();
    for(int level=1; level<height; ++level) {
        inlineWalk<Count>(query_node_list, start_idx, node_list, r, data_d, qid_list, node_num, max_node_num, data_info, empty_list, data_s, size_s, work);
        // Finish every read of the old parents before any lane clears one.
        __syncthreads();
        inlineClear(query_node_list, start_idx, node_num, max_node_num, empty_list);
        __syncthreads();
        start_idx += node_num; node_num *= TREE_ORDER;
    }
}


template<int Layout> __device__ __forceinline__ void inlineWalkLayout(int *query_node_list, int start_idx, TN *node_list, float r, float *data_d,
							int *qid_list, int node_num, int *max_node_num, int *data_info, int *empty_list, char *data_s, int *size_s, const int *pids, const float *lower, const float *packed)
{
	int bid = blockIdx.x;
	int tid = threadIdx.x;
	int query_id = bid;

	for (int i = tid; i < node_num; i += blockDim.x)
	{
		int nid = start_idx + i;
		int nid_parent = (nid - 1) / TREE_ORDER;

		if ((query_node_list[query_id * max_node_num[0] + nid_parent] == 1) && (empty_list[nid] == 0))
		{
			TN node; node.pid = pids[nid]; node.min_dis = lower[nid];

			float dis_q = 0;
			if (data_info[2] == 2)
			{ // L2 distance
				for (int j = 0; j < data_info[0]; j++)
				{
					dis_q += pow((Layout ? packed[pivotOffset(Layout,(nid - 1) / 10,j,data_info[0])] : data_d[node.pid * data_info[0] + j]) - data_d[qid_list[query_id] * data_info[0] + j], 2);
				}
				dis_q = pow(dis_q, 0.5);
			}
			else if (data_info[2] == 1)
			{ // L1 distance
				for (int j = 0; j < data_info[0]; j++)
				{
					dis_q += abs((Layout ? packed[pivotOffset(Layout,(nid - 1) / 10,j,data_info[0])] : data_d[node.pid * data_info[0] + j]) - data_d[qid_list[query_id] * data_info[0] + j]);
				}
			}
			else if (data_info[2] == 0)
			{ // Max value
				float temp = 0;
				for (int j = 0; j < data_info[0]; j++)
				{
					temp = abs((Layout ? packed[pivotOffset(Layout,(nid - 1) / 10,j,data_info[0])] : data_d[node.pid * data_info[0] + j]) - data_d[qid_list[query_id] * data_info[0] + j]);
					if (temp > dis_q)
						dis_q = temp;
				}
			}
			else if (data_info[2] == 5)
			{
				float sa1 = 0, sa2 = 0, sa3 = 0;
				for (int j = 0; j < data_info[0]; j++)
				{
					sa1 += (Layout ? packed[pivotOffset(Layout,(nid - 1) / 10,j,data_info[0])] : data_d[node.pid * data_info[0] + j]) * (Layout ? packed[pivotOffset(Layout,(nid - 1) / 10,j,data_info[0])] : data_d[node.pid * data_info[0] + j]);
					sa2 += data_d[qid_list[query_id] * data_info[0] + j] * data_d[qid_list[query_id] * data_info[0] + j];
					sa3 += (Layout ? packed[pivotOffset(Layout,(nid - 1) / 10,j,data_info[0])] : data_d[node.pid * data_info[0] + j]) * data_d[qid_list[query_id] * data_info[0] + j];
				}
				sa1 = pow(sa1, 0.5);
				sa2 = pow(sa2, 0.5);
				if (sa1 * sa2 == 0)
				{
					printf("Error!!!\n");
				}
				dis_q = sa3 / (sa1 * sa2);
				if (dis_q > 1)
				{
					dis_q = 0.99999999999999999;
				}
				dis_q = abs(acos(dis_q) * 180 / 3.1415926);
			}
			else if (data_info[2] == 6)
			{
				int n = size_s[node.pid];
				int m = size_s[qid_list[query_id]];
				int table[M][M];
				if (n == 0)
					dis_q = m;
				if (m == 0)
					dis_q = n;
				if (n != 0 && m != 0)
				{
					for (int j = 0; j <= n; j++)
						table[j][0] = j;
					for (int k = 0; k <= m; k++)
						table[0][k] = k;
					for (int j = 1; j <= n; j++)
					{
						for (int k = 1; k <= m; k++)
						{
							int cost = (data_s[node.pid * M + j - 1] == data_s[qid_list[query_id] * M + k - 1]) ? 0 : 1;
							table[j][k] = 1 + min(table[j - 1][k], table[j][k - 1]);
							table[j][k] = min(table[j - 1][k - 1] + cost, table[j][k]);
						}
					}
					dis_q = table[n][m];
				}
			}

			float dis_lb = node.min_dis - dis_q;
			dis_lb = max(dis_lb, 0.0);
			if (nid % TREE_ORDER != 0)
			{
				float dis_lb2 = dis_q - lower[nid + 1];
				dis_lb = max(dis_lb, dis_lb2);
			}

			if (dis_lb <= r)
				query_node_list[query_id * max_node_num[0] + nid] = 1;
		}
	}
}


template<int Layout>
__global__ void fusedTraversalLayout(int *query_node_list, int start_idx, TN *node_list, float r, float *data_d,
							int *qid_list, int node_num, int *max_node_num, int *data_info, int *empty_list, char *data_s, int *size_s, int height, const int *pids, const float *lower, const float *packed) {
    inlineInit(query_node_list, 1, max_node_num);
    __syncthreads();
    for(int level=1; level<height; ++level) {
        inlineWalkLayout<Layout>(query_node_list, start_idx, node_list, r, data_d, qid_list, node_num, max_node_num, data_info, empty_list, data_s, size_s, pids, lower, packed);
        // Finish every read of the old parents before any lane clears one.
        __syncthreads();
        inlineClear(query_node_list, start_idx, node_num, max_node_num, empty_list);
        __syncthreads();
        start_idx += node_num; node_num *= TREE_ORDER;
    }
}


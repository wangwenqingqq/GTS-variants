#pragma once
#include "layout_index.cuh"
template<int Layout> __global__ void findNextLayout(int *query_node_list, int start_idx, TN *node_list, float r, float *data_d,
							int *qid_list, int node_num, int *max_node_num, int *data_info, int *empty_list, char *data_s, int *size_s, const int *pids, const float *lower, const float *packed)
{
	int bid = blockIdx.x;
	int tid = threadIdx.x;
	int query_id = bid;

	for (int i = tid; i < node_num; i += blockDim.x)
	{
		int nid = start_idx + i;
		int nid_parent = (nid - 1) / TREE_ORDER;

		if ((query_node_list[query_id * max_node_num[0] + nid_parent] == 1) && (empty_list[nid] == 0))
		{
			TN node; node.pid = pids[nid]; node.min_dis = lower[nid];

			float dis_q = 0;
			if (data_info[2] == 2)
			{ // L2 distance
				for (int j = 0; j < data_info[0]; j++)
				{
					dis_q += pow((Layout ? packed[pivotOffset(Layout,(nid - 1) / 10,j,data_info[0])] : data_d[node.pid * data_info[0] + j]) - data_d[qid_list[query_id] * data_info[0] + j], 2);
				}
				dis_q = pow(dis_q, 0.5);
			}
			else if (data_info[2] == 1)
			{ // L1 distance
				for (int j = 0; j < data_info[0]; j++)
				{
					dis_q += abs((Layout ? packed[pivotOffset(Layout,(nid - 1) / 10,j,data_info[0])] : data_d[node.pid * data_info[0] + j]) - data_d[qid_list[query_id] * data_info[0] + j]);
				}
			}
			else if (data_info[2] == 0)
			{ // Max value
				float temp = 0;
				for (int j = 0; j < data_info[0]; j++)
				{
					temp = abs((Layout ? packed[pivotOffset(Layout,(nid - 1) / 10,j,data_info[0])] : data_d[node.pid * data_info[0] + j]) - data_d[qid_list[query_id] * data_info[0] + j]);
					if (temp > dis_q)
						dis_q = temp;
				}
			}
			else if (data_info[2] == 5)
			{
				float sa1 = 0, sa2 = 0, sa3 = 0;
				for (int j = 0; j < data_info[0]; j++)
				{
					sa1 += (Layout ? packed[pivotOffset(Layout,(nid - 1) / 10,j,data_info[0])] : data_d[node.pid * data_info[0] + j]) * (Layout ? packed[pivotOffset(Layout,(nid - 1) / 10,j,data_info[0])] : data_d[node.pid * data_info[0] + j]);
					sa2 += data_d[qid_list[query_id] * data_info[0] + j] * data_d[qid_list[query_id] * data_info[0] + j];
					sa3 += (Layout ? packed[pivotOffset(Layout,(nid - 1) / 10,j,data_info[0])] : data_d[node.pid * data_info[0] + j]) * data_d[qid_list[query_id] * data_info[0] + j];
				}
				sa1 = pow(sa1, 0.5);
				sa2 = pow(sa2, 0.5);
				if (sa1 * sa2 == 0)
				{
					printf("Error!!!\n");
				}
				dis_q = sa3 / (sa1 * sa2);
				if (dis_q > 1)
				{
					dis_q = 0.99999999999999999;
				}
				dis_q = abs(acos(dis_q) * 180 / 3.1415926);
			}
			else if (data_info[2] == 6)
			{
				int n = size_s[node.pid];
				int m = size_s[qid_list[query_id]];
				int table[M][M];
				if (n == 0)
					dis_q = m;
				if (m == 0)
					dis_q = n;
				if (n != 0 && m != 0)
				{
					for (int j = 0; j <= n; j++)
						table[j][0] = j;
					for (int k = 0; k <= m; k++)
						table[0][k] = k;
					for (int j = 1; j <= n; j++)
					{
						for (int k = 1; k <= m; k++)
						{
							int cost = (data_s[node.pid * M + j - 1] == data_s[qid_list[query_id] * M + k - 1]) ? 0 : 1;
							table[j][k] = 1 + min(table[j - 1][k], table[j][k - 1]);
							table[j][k] = min(table[j - 1][k - 1] + cost, table[j][k]);
						}
					}
					dis_q = table[n][m];
				}
			}

			float dis_lb = node.min_dis - dis_q;
			dis_lb = max(dis_lb, 0.0);
			if (nid % TREE_ORDER != 0)
			{
				float dis_lb2 = dis_q - lower[nid + 1];
				dis_lb = max(dis_lb, dis_lb2);
			}

			if (dis_lb <= r)
				query_node_list[query_id * max_node_num[0] + nid] = 1;
		}
	}
}


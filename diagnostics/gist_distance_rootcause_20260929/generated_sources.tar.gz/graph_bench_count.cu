// Fixed-capacity query control; original source is supplied separately.
#include <algorithm>
#include <cassert>
#include <chrono>
#include <cstdint>
#include <cstring>
#include <fstream>
#include <iomanip>
#include <numeric>
#include <string>
#include <vector>
#include <sys/resource.h>
#include <cub/cub.cuh>
#include <cstdlib>
#include <cmath>
#include <thrust/iterator/counting_iterator.h>
#define main original_gts_main
#include "source/src/main.cu"
#undef main
#undef short

using Clock = std::chrono::steady_clock;
double seconds(Clock::time_point t) { return std::chrono::duration<double>(Clock::now()-t).count(); }
void ck(cudaError_t e) { if(e!=cudaSuccess) { fprintf(stderr,"CUDA error: %s\n",cudaGetErrorString(e)); exit(2); } }
template<class T> void alloc(T*& p, size_t n) { ck(cudaMalloc(&p,n*sizeof(T))); }

// The original projection, with its logical length read on device; no fusion.
__global__ void projectBounded(const int* count, int* outid, float* outdis,
                              const int* ids, const float* ds, const int* prefix) {
    for(int i=blockIdx.x*blockDim.x+threadIdx.x;i<*count;i+=gridDim.x*blockDim.x) {
        outid[i]=ids[i]-prefix[ids[i]]; outdis[i]=ds[i];
    }
}

#include "fused_result.cuh"
#include "l2_traversal.cuh"
#include "leaf_l2.cuh"
#include "flat_l2.cuh"
#include "cutoff_l2.cuh"
#include "compact_cutoff.cuh"
#include "strict_l2.cuh"
#include "rootcause_l2.cuh"

int query_slots=0,used_nodes=0,leaf_nodes=0;

struct Fixed {
    bool fused;
    bool strict, fast;
    int root_mode;
    float* packed;
    int* processed=nullptr;
    unsigned long long *lower, *upper;
    int traversal;
    bool skip_dead_count;
    int leaf_mode;
    int stop_depth;
    int* node_for_pos=nullptr;
    int* active=nullptr;
    int* candidate_positions=nullptr;
    const int nodes, slots;
    int n, height;
    cudaStream_t stream;
    cudaGraph_t graph=nullptr;
    cudaGraphExec_t executable=nullptr;
    void* temp=nullptr; size_t tempbytes=0;
    int *qid,*flags,*candidates,*queryids,*nodecount,*nodeprefix,*nodeidx;
    int *candidate_count,*hit_count,*hits,*count,*prefix,*rawids,*ids,*outids;
    float *rawdis,*ds,*outdis;
    int *hq,*hc,*hi; float* hd;
    Fixed(int count_n,int h,bool f=false,int t=0,bool skip=false,int lm=0,int sd=0,const std::vector<TN>* host_tree=nullptr,const std::vector<int>* host_empty=nullptr,bool sm=false,bool fm=false,unsigned long long* lb=nullptr,unsigned long long* ub=nullptr,int rm=0,float* pack=nullptr):fused(f),strict(sm),fast(fm),root_mode(rm),packed(pack),lower(lb),upper(ub),traversal(t),skip_dead_count(skip),leaf_mode(lm),stop_depth(sd),nodes(max_node_num[0]),slots(nodes*20),n(count_n),height(h) {
        ck(cudaStreamCreateWithFlags(&stream,cudaStreamNonBlocking));
        if(root_mode)alloc(processed,n);
        alloc(qid,1);alloc(flags,nodes);alloc(candidates,nodes);alloc(queryids,nodes);
        alloc(nodecount,1);alloc(nodeprefix,1);alloc(nodeidx,nodes);
        alloc(candidate_count,1);alloc(hit_count,1);alloc(hits,slots);alloc(count,1);alloc(prefix,1);
        alloc(rawids,slots);alloc(rawdis,slots);alloc(ids,slots);alloc(ds,slots);alloc(outids,slots);alloc(outdis,slots);
        ck(cudaMallocHost(&hq,sizeof(int)));ck(cudaMallocHost(&hc,sizeof(int)));
        ck(cudaMallocHost(&hi,slots*sizeof(int)));ck(cudaMallocHost(&hd,slots*sizeof(float)));
        if(leaf_mode==4||leaf_mode==6) {alloc(active,n);alloc(candidate_positions,n);}
        size_t z=0;
        ck(cub::DeviceReduce::Sum(nullptr,z,flags,candidate_count,nodes,stream));tempbytes=std::max(tempbytes,z);
        ck(cub::DeviceReduce::Sum(nullptr,z,hits,hit_count,slots,stream));tempbytes=std::max(tempbytes,z);
        ck(cub::DeviceScan::ExclusiveSum(nullptr,z,nodecount,nodeprefix,1,stream));tempbytes=std::max(tempbytes,z);
        ck(cub::DeviceScan::ExclusiveSum(nullptr,z,flags,nodeidx,nodes,stream));tempbytes=std::max(tempbytes,z);
        ck(cub::DeviceScan::InclusiveSum(nullptr,z,hits,hits,slots,stream));tempbytes=std::max(tempbytes,z);
        ck(cub::DeviceScan::InclusiveSum(nullptr,z,is_delete,is_delete_prefix,n,stream));tempbytes=std::max(tempbytes,z);
        if(leaf_mode==4||leaf_mode==6) {
            thrust::counting_iterator<int> positions(0);
            ck(cub::DeviceSelect::Flagged(nullptr,z,positions,active,candidate_positions,candidate_count,n,stream));
            tempbytes=std::max(tempbytes,z);
        }
        ck(cudaMalloc(&temp,tempbytes));
        // Initialize inactive payload capacity so fixed-size host delivery is defined.
        ck(cudaMemset(outids,0,slots*sizeof(int)));ck(cudaMemset(outdis,0,slots*sizeof(float)));
        if(stop_depth>0) {
            assert(host_tree && host_empty && stop_depth<height);
            int first=0, width=1;
            for(int level=0;level<stop_depth;++level) { first+=width; width*=TREE_ORDER; }
            assert(first+width<=int(host_tree->size()));
            std::vector<int> mapping(n,-1);
            for(int nid=first;nid<first+width;++nid) {
                if((*host_empty)[nid]!=0)continue;
                const TN& node=(*host_tree)[nid];
                assert(node.lid>=0 && node.size>0 && node.lid+node.size<=n);
                for(int pos=node.lid;pos<node.lid+node.size;++pos) {
                    assert(mapping[pos]==-1);mapping[pos]=nid;
                }
            }
            assert(std::all_of(mapping.begin(),mapping.end(),[](int nid){return nid>=0;}));
            alloc(node_for_pos,n);
            ck(cudaMemcpyAsync(node_for_pos,mapping.data(),n*sizeof(int),cudaMemcpyHostToDevice,stream));
            ck(cudaStreamSynchronize(stream));
        }
    }
    void enqueue(float radius) {
        ck(cudaMemcpyAsync(qid,hq,sizeof(int),cudaMemcpyHostToDevice,stream));
        if(strict) {
            const int d=data_info[0];
            if(leaf_mode==5) {
                if(root_mode==1)rootcauseFlat<false,false,true><<<(n+511)/512,512,0,stream>>>(id_list,data_d,packed,qid,n,d,radius,hits,rawids,rawdis,processed);
                else if(root_mode==2)rootcauseFlat<true,false,true><<<(n+511)/512,512,0,stream>>>(id_list,data_d,packed,qid,n,d,radius,hits,rawids,rawdis,processed);
                else if(root_mode==3)rootcauseFlat<false,true,true><<<(n+511)/512,512,0,stream>>>(id_list,data_d,packed,qid,n,d,radius,hits,rawids,rawdis,processed);
                else if(root_mode==4)rootcauseFlat<true,true,true><<<(n+511)/512,512,0,stream>>>(id_list,data_d,packed,qid,n,d,radius,hits,rawids,rawdis,processed);
                else if(fast)strict_flat<true><<<(n+511)/512,512,0,stream>>>(id_list,data_d,qid,n,d,radius,hits,rawids,rawdis);
                else strict_flat<false><<<(n+511)/512,512,0,stream>>>(id_list,data_d,qid,n,d,radius,hits,rawids,rawdis);
                ck(cub::DeviceScan::InclusiveSum(temp,tempbytes,is_delete,is_delete_prefix,n,stream));
                flatResultSelect<<<1,512,0,stream>>>(n,hits,rawids,rawdis,is_delete_prefix,count,outids,outdis);
            } else {
                initQnode<<<(nodes+511)/512,THREAD_NUM,0,stream>>>(flags,1,max_node_num);
                int start=1,width=TREE_ORDER;
                const int last=leaf_mode==6?stop_depth:height-1;
                for(int level=1;level<=last;++level) {
                    if(fast) strict_walk<true><<<(width+511)/512,512,0,stream>>>(flags,start,node_list,radius,data_d,qid,width,d,empty_list,lower,upper);
                    else strict_walk<false><<<(width+511)/512,512,0,stream>>>(flags,start,node_list,radius,data_d,qid,width,d,empty_list,lower,upper);
                    clear_parents<<<(width/TREE_ORDER+511)/512,512,0,stream>>>(flags,start,width);
                    start+=width;width*=TREE_ORDER;
                }
                if(leaf_mode==6) {
                    frontierFlags<<<(n+511)/512,512,0,stream>>>(n,node_for_pos,flags,active);
                    thrust::counting_iterator<int> positions(0);
                    ck(cub::DeviceSelect::Flagged(temp,tempbytes,positions,active,candidate_positions,candidate_count,n,stream));
                    if(fast)strict_compact<true><<<(n+511)/512,512,0,stream>>>(id_list,data_d,qid,n,d,radius,candidate_positions,candidate_count,hits,rawids,rawdis);
                    else strict_compact<false><<<(n+511)/512,512,0,stream>>>(id_list,data_d,qid,n,d,radius,candidate_positions,candidate_count,hits,rawids,rawdis);
                    ck(cub::DeviceScan::InclusiveSum(temp,tempbytes,is_delete,is_delete_prefix,n,stream));
                    compactResultSelect<<<1,512,0,stream>>>(candidate_count,n,hits,rawids,rawdis,is_delete_prefix,count,outids,outdis);
                } else {
                    ck(cub::DeviceReduce::Sum(temp,tempbytes,flags,candidate_count,nodes,stream));
                    initRes<<<(slots+511)/512,512,0,stream>>>(hits,slots);
                    ck(cub::DeviceScan::ExclusiveSum(temp,tempbytes,flags,nodeidx,nodes,stream));
                    mergeLeafNode<<<(nodes+511)/512,512,0,stream>>>(flags,nodeidx,candidates,max_node_num,1,queryids,0);
                    if(fast)strict_leaf<true><<<nodes,512,0,stream>>>(candidates,node_list,id_list,data_d,qid,d,radius,hits,rawids,rawdis,candidate_count);
                    else strict_leaf<false><<<nodes,512,0,stream>>>(candidates,node_list,id_list,data_d,qid,d,radius,hits,rawids,rawdis,candidate_count);
                    ck(cub::DeviceScan::InclusiveSum(temp,tempbytes,is_delete,is_delete_prefix,n,stream));
                    fusedResultSelect<<<1,512,0,stream>>>(candidate_count,hits,rawids,rawdis,is_delete_prefix,count,outids,outdis,nodes);
                }
            }
            ck(cudaMemcpyAsync(hc,count,sizeof(int),cudaMemcpyDeviceToHost,stream));
            ck(cudaMemcpyAsync(hi,outids,slots*sizeof(int),cudaMemcpyDeviceToHost,stream));
            ck(cudaMemcpyAsync(hd,outdis,slots*sizeof(float),cudaMemcpyDeviceToHost,stream));
            ck(cudaGetLastError());return;
        }
        if(leaf_mode==4||leaf_mode==6) {
            initQnode<<<(nodes+511)/512,THREAD_NUM,0,stream>>>(flags,1,max_node_num);
            int start=1,num=TREE_ORDER;
            for(int level=1;level<=stop_depth;++level) {
                l2Walk<true><<<(num+THREAD_NUM-1)/THREAD_NUM,THREAD_NUM,0,stream>>>(
                    flags,start,node_list,radius,data_d,qid,num,max_node_num,data_info,empty_list);
                updatePnodeFlag<<<1,THREAD_NUM,0,stream>>>(flags,start,num,max_node_num,empty_list);
                start+=num;num*=TREE_ORDER;
            }
            frontierFlags<<<(n+511)/512,512,0,stream>>>(n,node_for_pos,flags,active);
            thrust::counting_iterator<int> positions(0);
            ck(cub::DeviceSelect::Flagged(temp,tempbytes,positions,active,
                candidate_positions,candidate_count,n,stream));
            const float guarded=radius+0.001f;
            const double cutoff=double(guarded)*double(guarded);
            compactL2<<<(n+511)/512,512,0,stream>>>(id_list,data_d,qid,data_info,radius,
                is_delete,candidate_positions,candidate_count,cutoff,hits,rawids,rawdis);
            ck(cub::DeviceScan::InclusiveSum(temp,tempbytes,is_delete,is_delete_prefix,n,stream));
            compactResultSelect<<<1,512,0,stream>>>(candidate_count,n,hits,rawids,rawdis,
                is_delete_prefix,count,outids,outdis);
            ck(cudaMemcpyAsync(hc,count,sizeof(int),cudaMemcpyDeviceToHost,stream));
            ck(cudaMemcpyAsync(hi,outids,slots*sizeof(int),cudaMemcpyDeviceToHost,stream));
            ck(cudaMemcpyAsync(hd,outdis,slots*sizeof(float),cudaMemcpyDeviceToHost,stream));
            ck(cudaGetLastError());return;
        }
        if(leaf_mode==3) {
            if(stop_depth>0) {
                initQnode<<<(nodes+511)/512,THREAD_NUM,0,stream>>>(flags,1,max_node_num);
                int start=1, num=TREE_ORDER;
                for(int level=1;level<=stop_depth;++level) {
                    l2Walk<true><<<(num+THREAD_NUM-1)/THREAD_NUM,THREAD_NUM,0,stream>>>(
                        flags,start,node_list,radius,data_d,qid,num,max_node_num,data_info,empty_list);
                    updatePnodeFlag<<<1,THREAD_NUM,0,stream>>>(flags,start,num,max_node_num,empty_list);
                    start+=num;num*=TREE_ORDER;
                }
            }
            const float guarded=radius+0.001f;
            const double cutoff=double(guarded)*double(guarded);
            if(stop_depth==0)
                flatL2<<<(n+511)/512,512,0,stream>>>(id_list,data_d,qid,data_info,radius,
                    is_delete,n,cutoff,hits,rawids,rawdis);
            else
                cutoffL2<<<(n+511)/512,512,0,stream>>>(id_list,data_d,qid,data_info,radius,
                    is_delete,n,cutoff,node_for_pos,flags,hits,rawids,rawdis);
            ck(cub::DeviceScan::InclusiveSum(temp,tempbytes,is_delete,is_delete_prefix,n,stream));
            flatResultSelect<<<1,512,0,stream>>>(n,hits,rawids,rawdis,is_delete_prefix,
                count,outids,outdis);
            ck(cudaMemcpyAsync(hc,count,sizeof(int),cudaMemcpyDeviceToHost,stream));
            ck(cudaMemcpyAsync(hi,outids,slots*sizeof(int),cudaMemcpyDeviceToHost,stream));
            ck(cudaMemcpyAsync(hd,outdis,slots*sizeof(float),cudaMemcpyDeviceToHost,stream));
            ck(cudaGetLastError());return;
        }
        initQnode<<<(nodes+511)/512,THREAD_NUM,0,stream>>>(flags,1,max_node_num);
        int start=1, num=10;
        for(int level=1;level<height;++level) {
            if(traversal == 0) {
                findNextRnn<<<1,THREAD_NUM,0,stream>>>(flags,start,node_list,radius,data_d,qid,num,max_node_num,data_info,empty_list,data_s,size_s);
            } else if(traversal == 1) {
                l2Walk<false><<<1,THREAD_NUM,0,stream>>>(flags,start,node_list,radius,data_d,qid,num,max_node_num,data_info,empty_list);
            } else {
                l2Walk<true><<<(num+THREAD_NUM-1)/THREAD_NUM,THREAD_NUM,0,stream>>>(flags,start,node_list,radius,data_d,qid,num,max_node_num,data_info,empty_list);
            }
            updatePnodeFlag<<<1,THREAD_NUM,0,stream>>>(flags,start,num,max_node_num,empty_list);
            start+=num; num*=10;
        }
        ck(cub::DeviceReduce::Sum(temp,tempbytes,flags,candidate_count,nodes,stream));
        initRes<<<(slots+511)/512,512,0,stream>>>(hits,slots);
        if(!skip_dead_count) {
            getQnodeCount<<<1,512,0,stream>>>(1,flags,max_node_num,nodecount,0);
            ck(cub::DeviceScan::ExclusiveSum(temp,tempbytes,nodecount,nodeprefix,1,stream));
        }
        ck(cub::DeviceScan::ExclusiveSum(temp,tempbytes,flags,nodeidx,nodes,stream));
        mergeLeafNode<<<(nodes+511)/512,512,0,stream>>>(flags,nodeidx,candidates,max_node_num,1,queryids,0);
        if(leaf_mode==0) {
            leafProcessRnnUpdate<<<nodes,512,0,stream>>>(candidates,node_list,id_list,queryids,data_d,qid,
                rawids,rawdis,data_info,radius,hits,candidate_count,data_s,size_s,is_delete);
        } else {
            const float guarded=radius+0.001f;
            const double cutoff=double(guarded)*double(guarded);
            if(leaf_mode==1) leafL2<false><<<nodes,512,0,stream>>>(candidates,node_list,id_list,queryids,data_d,qid,
                rawids,rawdis,data_info,radius,hits,candidate_count,is_delete,cutoff);
            else leafL2<true><<<nodes,512,0,stream>>>(candidates,node_list,id_list,queryids,data_d,qid,
                rawids,rawdis,data_info,radius,hits,candidate_count,is_delete,cutoff);
        }
        if(fused) {
            ck(cub::DeviceScan::InclusiveSum(temp,tempbytes,is_delete,is_delete_prefix,n,stream));
            fusedResultSelect<<<1,512,0,stream>>>(candidate_count,hits,rawids,rawdis,is_delete_prefix,count,outids,outdis,nodes);
        } else {
        ck(cub::DeviceReduce::Sum(temp,tempbytes,hits,hit_count,slots,stream));
        getQresultCount<<<1,512,0,stream>>>(1,nodecount,nodeprefix,count,hits);
        ck(cub::DeviceScan::ExclusiveSum(temp,tempbytes,count,prefix,1,stream));
        ck(cub::DeviceScan::InclusiveSum(temp,tempbytes,hits,hits,slots,stream));
        mergeResultRnn<<<(slots+511)/512,512,0,stream>>>(hits,rawids,rawdis,ids,ds,candidate_count);
        ck(cub::DeviceScan::InclusiveSum(temp,tempbytes,is_delete,is_delete_prefix,n,stream));
        projectBounded<<<(slots+511)/512,512,0,stream>>>(count,outids,outdis,ids,ds,is_delete_prefix);
        }
        ck(cudaMemcpyAsync(hc,count,sizeof(int),cudaMemcpyDeviceToHost,stream));
        ck(cudaMemcpyAsync(hi,outids,slots*sizeof(int),cudaMemcpyDeviceToHost,stream));
        ck(cudaMemcpyAsync(hd,outdis,slots*sizeof(float),cudaMemcpyDeviceToHost,stream));
        ck(cudaGetLastError());
    }
    double capture(float radius) {
        auto t=Clock::now();
        ck(cudaStreamBeginCapture(stream,cudaStreamCaptureModeGlobal));enqueue(radius);
        ck(cudaStreamEndCapture(stream,&graph));
        ck(cudaGraphInstantiate(&executable,graph,0));return seconds(t);
    }
    void query(int q,float radius,bool replay) {
        *hq=q;
        if(replay)ck(cudaGraphLaunch(executable,stream));else enqueue(radius);
        ck(cudaStreamSynchronize(stream));
        if(*hc<0 || *hc>slots) { fprintf(stderr,"Capacity failure\n");exit(3); }
    }
    ~Fixed() {
        if(executable)ck(cudaGraphExecDestroy(executable));if(graph)ck(cudaGraphDestroy(graph));
        if(processed)ck(cudaFree(processed));
        if(node_for_pos)ck(cudaFree(node_for_pos));
        if(active)ck(cudaFree(active));
        if(candidate_positions)ck(cudaFree(candidate_positions));
        for(void* p:{(void*)qid,(void*)flags,(void*)candidates,(void*)queryids,(void*)nodecount,(void*)nodeprefix,(void*)nodeidx,
                    (void*)candidate_count,(void*)hit_count,(void*)hits,(void*)count,(void*)prefix,(void*)rawids,(void*)rawdis,
                    (void*)ids,(void*)ds,(void*)outids,(void*)outdis,temp})ck(cudaFree(p));
        ck(cudaFreeHost(hq));ck(cudaFreeHost(hc));ck(cudaFreeHost(hi));ck(cudaFreeHost(hd));ck(cudaStreamDestroy(stream));
    }
};

void original_query(int q,float radius,int& count,std::vector<int>& ids,std::vector<float>& ds) {
    qid_list[0]=q;
    searchIndexRnnUpdate(data_d,node_list,id_list,max_node_num,qid_list,1,radius,tree_h,data_info,empty_list,
                        qresult_count,qresult_count_prefix,result_id,result_dis,data_s,size_s);
    count=qresult_count[0]; assert(count>=0 && count<=query_slots);
    ck(cudaMallocManaged(&total_result_id,count*sizeof(int)));ck(cudaMallocManaged(&total_result_dis,count*sizeof(float)));
    thrust::inclusive_scan(thrust::device,is_delete,is_delete+tree_size,is_delete_prefix);
    mergeTotalResult<<<(count-1)/512+1,512>>>(count,total_result_id,qresult_count,result_id,result_dis,obj_r,total_result_dis,is_delete_prefix,tree_size);
    ck(cudaDeviceSynchronize());
    for(int i=0;i<count;++i) {ids[i]=total_result_id[i];ds[i]=total_result_dis[i];}
    for(void* p:{(void*)total_result_id,(void*)total_result_dis,(void*)qresult_count,(void*)qresult_count_prefix,(void*)result_id,(void*)result_dis})ck(cudaFree(p));
}

uint64_t digest(int count,const int* ids,const float* ds) {
    uint64_t h=1469598103934665603ull;
    for(int i=0;i<count;++i) {uint32_t bits;memcpy(&bits,ds+i,4);h=(h^uint32_t(ids[i]))*1099511628211ull;h=(h^bits)*1099511628211ull;}
    return (h^uint32_t(count))*1099511628211ull;
}
double cpu_time() {rusage u{};getrusage(RUSAGE_SELF,&u);return u.ru_utime.tv_sec+u.ru_utime.tv_usec*1e-6+u.ru_stime.tv_sec+u.ru_stime.tv_usec*1e-6;}

// Experiment-only bulk float32 input. Runs before index construction and timers.
void loadBinaryL2(const char* filename) {
    std::ifstream in(filename,std::ios::binary);assert(in.good());
    int header[3];in.read(reinterpret_cast<char*>(header),sizeof(header));assert(in.gcount()==sizeof(header));
    const int dim=header[0], n=header[1], metric=header[2];
    assert(metric==2 && n>=2000 && n<=1000000 && (dim>=2 && dim<=960));
    ck(cudaMallocManaged((void**)&data_info,3*sizeof(int)));
    for(int i=0;i<3;++i)data_info[i]=header[i];
    const size_t bytes=size_t(n)*size_t(dim)*sizeof(float);
    ck(cudaMallocManaged((void**)&data_d,bytes));
    in.read(reinterpret_cast<char*>(data_d),std::streamsize(bytes));assert(in.gcount()==std::streamsize(bytes));
    char extra;assert(!in.read(&extra,1));data_s=nullptr;size_s=nullptr;
}


double buildStrictBounds(const std::vector<TN>& tree,const std::vector<int>& empty,
                         int n,int d,int height,unsigned long long*& low,
                         unsigned long long*& high,uint64_t& digest_out) {
    auto begin=Clock::now();const int nodes=int(tree.size());
    std::vector<unsigned long long> lo(nodes,~0ull),hi(nodes,0);
    alloc(low,nodes);alloc(high,nodes);
    ck(cudaMemcpy(low,lo.data(),nodes*sizeof(unsigned long long),cudaMemcpyHostToDevice));
    ck(cudaMemcpy(high,hi.data(),nodes*sizeof(unsigned long long),cudaMemcpyHostToDevice));
    int* dev_map;alloc(dev_map,n);std::vector<int> mapping(n);
    int start=1,width=TREE_ORDER;
    for(int level=1;level<height;++level) {
        std::fill(mapping.begin(),mapping.end(),-1);
        assert(start+width<=nodes);
        for(int nid=start;nid<start+width;++nid)if(empty[nid]==0) {
            const TN node=tree[nid];
            assert(node.pid>=0&&node.pid<n&&node.lid>=0&&node.size>0&&node.lid+node.size<=n);
            for(int pos=node.lid;pos<node.lid+node.size;++pos){assert(mapping[pos]==-1);mapping[pos]=nid;}
        }
        assert(std::all_of(mapping.begin(),mapping.end(),[](int x){return x>=0;}));
        ck(cudaMemcpy(dev_map,mapping.data(),n*sizeof(int),cudaMemcpyHostToDevice));
        refit_bounds<<<(n+255)/256,256>>>(dev_map,id_list,node_list,data_d,n,d,low,high);
        ck(cudaGetLastError());ck(cudaDeviceSynchronize());
        start+=width;width*=TREE_ORDER;
    }
    ck(cudaMemcpy(lo.data(),low,nodes*sizeof(unsigned long long),cudaMemcpyDeviceToHost));
    ck(cudaMemcpy(hi.data(),high,nodes*sizeof(unsigned long long),cudaMemcpyDeviceToHost));
    uint64_t hash=1469598103934665603ull;
    for(int nid=1;nid<nodes;++nid)if(empty[nid]==0) {
        assert(lo[nid]!=~0ull&&hi[nid]!=0&&lo[nid]<=hi[nid]);
        hash=(hash^lo[nid])*1099511628211ull;
        hash=(hash^hi[nid])*1099511628211ull;
    }
    digest_out=hash;ck(cudaFree(dev_map));return seconds(begin);
}

int main(int argc,char** argv) {
    if(argc!=9) {fprintf(stderr,"usage: graph_bench data qids Q|H|J|F|D1|D2|D3|D4|D5|C1|C2|C3|C4|C5 radius repeats warmup output_prefix dump\n");return 1;}
    std::string mode=argv[3],out=argv[7];float radius=std::stof(argv[4]);int repeats=std::stoi(argv[5]),warmup=std::stoi(argv[6]);bool dump=std::stoi(argv[8]);
    const bool rootcause=mode=="B"||mode=="L"||mode=="E64"||mode=="L_E64";
    const int root_mode=mode=="B"?1:(mode=="L"?2:(mode=="E64"?3:(mode=="L_E64"?4:0)));
    const bool strict=rootcause||mode=="FR"||mode=="FF"||mode=="TR"||mode=="TF"||
        mode=="CR1"||mode=="CR2"||mode=="CR3"||mode=="CR4"||mode=="CR5"||
        mode=="CF1"||mode=="CF2"||mode=="CF3"||mode=="CF4"||mode=="CF5";
    const bool fast=strict&&!rootcause&&mode[1]=='F';
    assert((mode=="Q"||mode=="H"||mode=="J"||mode=="F"||mode=="D1"||mode=="D2"||mode=="D3"||mode=="D4"||mode=="D5"||mode=="C1"||mode=="C2"||mode=="C3"||mode=="C4"||mode=="C5"||strict) && repeats>0 && warmup>=0);
    assert(std::isfinite(radius));
    auto process_start=Clock::now();loadBinaryL2(argv[1]);
    if(rootcause)for(size_t i=0;i<size_t(data_info[0])*data_info[1];++i)
        if(!std::isfinite(data_d[i])){fprintf(stderr,"Nonfinite input at %zu\n",i);return 4;}
    assert(data_info[1]>=2000 && data_info[1]<=1000000 && data_info[2]==2 && (data_info[0]>=2 && data_info[0]<=960));
    MAX_H=1;for(int worst=data_info[1];worst>20;worst-=9*(worst/10))++MAX_H;
    assert(MAX_H>=3 && MAX_H<=6);
    std::ifstream qf(argv[2]);int nq; qf>>nq;assert(nq>0);std::vector<int> queries(nq);
    for(int& q:queries){qf>>q;assert(q>=0 && q<data_info[1]);}assert(qf.good());
    indexConstru(data_d,data_s,size_s,data_info,id_list,node_list,max_node_num,tree_h,empty_list);ck(cudaDeviceSynchronize());
    assert(tree_h==MAX_H && MAX_SIZE==20 && TREE_ORDER==10);
    query_slots=max_node_num[0]*20;
    std::vector<TN> tree(max_node_num[0]);std::vector<int> empty(max_node_num[0]),ids(data_info[1]),seen(data_info[1],0),cover(data_info[1],0);
    ck(cudaMemcpy(tree.data(),node_list,tree.size()*sizeof(TN),cudaMemcpyDeviceToHost));
    ck(cudaMemcpy(empty.data(),empty_list,empty.size()*sizeof(int),cudaMemcpyDeviceToHost));
    ck(cudaMemcpy(ids.data(),id_list,ids.size()*sizeof(int),cudaMemcpyDeviceToHost));
    uint64_t idlist_hash=1469598103934665603ull;
    for(int id:ids){assert(id>=0&&id<data_info[1]);assert(++seen[id]==1);
        idlist_hash=(idlist_hash^uint32_t(id))*1099511628211ull;}
    if(strict)if(const char* path=getenv("GTS_DUMP_IDLIST")) {
        std::ofstream order(path,std::ios::binary);
        order.write(reinterpret_cast<const char*>(ids.data()),ids.size()*sizeof(int));
        assert(bool(order));
    }
    for(size_t i=0;i<tree.size();++i)if(empty[i]==0){
        ++used_nodes;auto node=tree[i];assert(node.size>0&&node.lid>=0&&node.lid+node.size<=data_info[1]);
        if(node.is_leaf==1){++leaf_nodes;assert(node.size<=20);for(int j=node.lid;j<node.lid+node.size;++j)assert(++cover[j]==1);}
    }
    assert(std::all_of(cover.begin(),cover.end(),[](int x){return x==1;}));
    unsigned long long *strict_low=nullptr,*strict_high=nullptr;
    uint64_t bound_hash=0;double refit_s=0;
    if(strict)refit_s=buildStrictBounds(tree,empty,data_info[1],data_info[0],tree_h,
                                       strict_low,strict_high,bound_hash);
    float* packed=nullptr;double layout_s=0;size_t layout_bytes=0;
    if(root_mode==2||root_mode==4) {
        auto layout_start=Clock::now();
        layout_bytes=size_t(data_info[1])*data_info[0]*sizeof(float);
        alloc(packed,size_t(data_info[1])*data_info[0]);
        rootcausePack32<<<(data_info[1]+511)/512,512>>>(id_list,data_d,packed,data_info[1],data_info[0]);
        ck(cudaGetLastError());ck(cudaDeviceSynchronize());
        layout_s=seconds(layout_start);
    }
    qnum_leaf=1;
    tree_size=data_info[1];ck(cudaMallocManaged(&is_delete,tree_size*sizeof(int)));ck(cudaMallocManaged(&is_delete_prefix,tree_size*sizeof(int)));
    ck(cudaMemset(is_delete,0,tree_size*sizeof(int)));ck(cudaMallocManaged(&qid_list,sizeof(int)));ck(cudaDeviceSynchronize());
    std::vector<int> host_ids(query_slots);std::vector<float> host_ds(query_slots);int count=0;
    auto setup=Clock::now();int leaf_mode=strict?(rootcause?5:(mode[0]=='F'?5:(mode[0]=='C'?6:7))):
        (mode=="Q"?0:(mode=="H"?1:(mode=="J"?2:(mode[0]=='C'?4:3))));
    int depth=strict?(mode[0]=='C'?mode[2]-'0':0):
        ((mode[0]=='D'||mode[0]=='C')?mode[1]-'0':0);
    Fixed* fixed=new Fixed(tree_size,tree_h,true,2,true,leaf_mode,depth,&tree,&empty,
                           strict,fast,strict_low,strict_high,root_mode,packed);double capture_s=0;
    *fixed->hq=queries[0];capture_s=fixed->capture(radius);
    double setup_s=seconds(setup);
    auto call=[&](int q){if(fixed){fixed->query(q,radius,true);count=*fixed->hc;}else original_query(q,radius,count,host_ids,host_ds);};
    auto first=Clock::now();call(queries[0]);double first_s=seconds(first);
    for(int i=0;i<warmup;++i)call(queries[i%nq]);
    const char* dims_path=getenv("GTS_DIMS_OUTPUT");
    std::ofstream dims_out;
    if(dims_path){dims_out.open(dims_path);assert(bool(dims_out));
        dims_out<<"qid,count,ordered_hash,sum_dims,dim_hist,group_max_hist\n";}
    std::ofstream full,work,binary;
    if(dump){
        if(strict)binary.open(out+".bin",std::ios::binary);
        else {full.open(out+".results");full<<std::setprecision(9);}
        work.open(out+".work.csv");work<<"qid,candidates\n";
    }
    std::vector<double> us;std::vector<int> counts;std::vector<uint64_t> hashes;
    us.reserve(nq*repeats);counts.reserve(nq*repeats);hashes.reserve(nq*repeats);
    double cpu_start=cpu_time();auto loop=Clock::now();
    for(int j=0;j<repeats;++j)for(int q:queries) {
        auto t=Clock::now();call(q);us.push_back(seconds(t)*1e6);
        const int* ids=fixed?fixed->hi:host_ids.data();const float* ds=fixed?fixed->hd:host_ds.data();
        counts.push_back(count);hashes.push_back(digest(count,ids,ds));
        if(dims_path) {
            std::vector<int> values(tree_size);std::vector<unsigned long long> hist((data_info[0]+31)/32+1,0);
            std::vector<unsigned long long> groups(hist.size(),0);
            ck(cudaMemcpy(values.data(),fixed->processed,size_t(tree_size)*sizeof(int),cudaMemcpyDeviceToHost));
            unsigned long long sum_dims=0;
            for(int pos=0;pos<tree_size;++pos){const int v=values[pos];
                assert(v>=0&&v<=data_info[0]);sum_dims+=v;++hist[(v+31)/32];}
            for(int first=0;first<tree_size;first+=32){int longest=0;
                for(int pos=first;pos<std::min(first+32,tree_size);++pos)
                    longest=std::max(longest,values[pos]);
                ++groups[(longest+31)/32];}
            dims_out<<q<<','<<count<<','<<hashes.back()<<','<<sum_dims<<',';
            for(size_t i=0;i<hist.size();++i){if(i)dims_out<<'|';dims_out<<hist[i];}
            dims_out<<',';for(size_t i=0;i<groups.size();++i){if(i)dims_out<<'|';dims_out<<groups[i];}
            dims_out<<'\n';
        }
        if(dump && fixed){int nc;ck(cudaMemcpy(&nc,fixed->candidate_count,4,cudaMemcpyDeviceToHost));work<<q<<','<<nc<<'\n';}
        if(dump){
            if(strict){
                binary.write(reinterpret_cast<const char*>(&q),sizeof(q));
                binary.write(reinterpret_cast<const char*>(&count),sizeof(count));
                binary.write(reinterpret_cast<const char*>(ids),size_t(count)*sizeof(int));
                binary.write(reinterpret_cast<const char*>(ds),size_t(count)*sizeof(float));
                assert(bool(binary));
            } else {full<<q<<' '<<count;for(int i=0;i<count;++i)full<<' '<<ids[i]<<':'<<ds[i];full<<'\n';}
        }
    }
    double loop_s=seconds(loop),cpu_s=cpu_time()-cpu_start;
    std::ofstream samples(out+".csv");samples<<"qid,query_us,count,ordered_hash\n";samples<<std::setprecision(12);
    for(size_t i=0;i<us.size();++i)samples<<queries[i%nq]<<','<<us[i]<<','<<counts[i]<<','<<hashes[i]<<'\n';
    std::ofstream summary(out+".json");summary<<std::setprecision(12)
      <<"{\"mode\":\""<<mode<<"\",\"queries\":"<<us.size()<<",\"radius\":"<<radius
      <<",\"n\":"<<tree_size<<",\"tree_height\":"<<tree_h<<",\"nodes\":"<<max_node_num[0]<<",\"slots\":"<<query_slots<<",\"idlist_hash\":"<<idlist_hash<<",\"used_nodes\":"<<used_nodes<<",\"leaves\":"<<leaf_nodes
      <<",\"refit_s\":"<<refit_s<<",\"bounds_hash\":"<<bound_hash<<",\"layout_s\":"<<layout_s<<",\"layout_bytes\":"<<layout_bytes<<",\"setup_s\":"<<setup_s<<",\"capture_instantiate_s\":"<<capture_s<<",\"first_query_s\":"<<first_s
      <<",\"sum_query_s\":"<<std::accumulate(us.begin(),us.end(),0.0)/1e6<<",\"loop_wall_s\":"<<loop_s
      <<",\"loop_cpu_s\":"<<cpu_s<<",\"before_cleanup_process_s\":"<<seconds(process_start)<<"}\n";
    delete fixed;if(packed)ck(cudaFree(packed));
    if(strict_low)ck(cudaFree(strict_low));if(strict_high)ck(cudaFree(strict_high));
    ck(cudaFree(qid_list));ck(cudaFree(is_delete));ck(cudaFree(is_delete_prefix));
    for(void* p:{(void*)data_info,(void*)data_d,(void*)data_s,(void*)size_s,(void*)id_list,(void*)node_list,(void*)max_node_num,(void*)empty_list})if(p)ck(cudaFree(p));
    printf("PASS completed %s %zu queries\n",mode.c_str(),us.size());
}
